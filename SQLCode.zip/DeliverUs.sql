-- Codigo del proyecto realizado por el grupo 2

-- Eliminamos la database en caso de que exista para crearla de nuevo
DROP DATABASE if EXISTS deliverus;
-- Creamos la database, o la reemplazamos en caso de que exista
CREATE OR REPLACE DATABASE deliverus;
-- Indicamos que vamos a usar la database que acabamos de crear llamada deliverus
USE deliverus;
-- Eliminamos las tablas para crearlas de nuevo
DROP TABLE if EXISTS FinalPrices;
DROP TABLE if EXISTS Addresses;
DROP TABLE if EXISTS Delivers;
DROP TABLE if EXISTS Discounts;
DROP TABLE if EXISTS ProductLines;
DROP TABLE if EXISTS Products;
DROP TABLE if EXISTS DeliveryMen;
DROP TABLE if EXISTS Restaurants;
DROP TABLE if EXISTS Clients;
DROP TABLE if EXISTS Users;


-- PROCEDIMIENTOS --
																		
-- Este prodecimiento lleva a cabo la creacion de las tablas en la database
DELIMITER //
CREATE OR REPLACE PROCEDURE createTables()
   BEGIN
	   	CREATE TABLE Users(
	   userId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   `name` VARCHAR(32) NOT NULL,
	   surname1 VARCHAR(32) NOT NULL,
	   surname2 VARCHAR(32) NOT NULL,
	   email VARCHAR(64) NOT NULL UNIQUE,
	   phone VARCHAR(9) NOT NULL UNIQUE,
	   username CHAR(32) NOT NULL UNIQUE,
	   `password` VARCHAR(32) NOT NULL,
	   avatar VARCHAR(256),
	   payMethod ENUM('Visa','PayPal') NOT NULL,
	   postalCode VARCHAR(5) NOT NULL,
	   CONSTRAINT passwordLength CHECK(LENGTH(`password`)>= 8),
	   CONSTRAINT postalCodeLength CHECK(LENGTH(postalCode) = 5),
	   CONSTRAINT phoneLength CHECK(LENGTH(phone) = 9)
	   );
	    
	   	CREATE TABLE Clients(
	   clientId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   userId INT NOT NULL,
	   FOREIGN KEY(userId) REFERENCES Users(userId)
	   );
	    
	   	CREATE TABLE Discounts(
	   discountId INT NOT NULL PRIMARY KEY,
	   multiplier DOUBLE NOT NULL,
	   CONSTRAINT multiplierCorrectValue CHECK(multiplier=1 OR multiplier=0.7)
	   );
	    
	   	CREATE TABLE Addresses(
	   addressId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   address VARCHAR(128) NOT NULL,
	   clientId INT NOT NULL,
	   FOREIGN KEY(clientId) REFERENCES clients(clientId)
	   );
	    
	   	CREATE TABLE DeliveryMen(
	   deliveryManId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   admissionDate DATE NOT NULL, 
	   vehicleType ENUM ('Coche','Moto','Bicicleta','Patinete') NOT NULL,
	   userId INT NOT NULL,
	   FOREIGN KEY (userId) REFERENCES Users(userId)
	   );
	    
	   	CREATE TABLE Restaurants(
	   restaurantId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   `name` VARCHAR(64) NOT NULL,
	   description VARCHAR(512) NOT NULL,
	   address VARCHAR(64) NOT NULL UNIQUE,
	   postalCode VARCHAR(5) NOT NULL,
	   phone VARCHAR(9) NOT NULL UNIQUE,
	   image VARCHAR(512) NOT NULL,
	   restaurantState ENUM('Open','Temporarily Closed','Permanently Closed') NOT NULL,
	   restaurantCategory ENUM('Italian','American','Chinese','Mediterranean','Turkey','Japanese','Thai') NOT NULL,
	   shippingPrice DOUBLE NOT NULL,
	   CONSTRAINT postalCodeLength CHECK(LENGTH(postalCode) = 5),
	   CONSTRAINT phoneLength CHECK(LENGTH(phone) = 9),
	   CONSTRAINT shoppingPricePositive CHECK(shippingPrice >= 0)
	   );
	    
	   	CREATE TABLE Products(
	   productId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   `name` VARCHAR(32) NOT NULL,
	   description VARCHAR(256) NOT NULL,
	   price DOUBLE NOT NULL,
	   image VARCHAR(256) NOT NULL,
	   disponibility BOOL NOT NULL,
	   restaurantId INT NOT NULL,
	   FOREIGN KEY(restaurantId) REFERENCES Restaurants(restaurantId),
	   CONSTRAINT pricePositive CHECK(price > 0)
	   );
	
	   	CREATE TABLE Delivers(
	   deliverId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   orderDatetime DATETIME NOT NULL,
	   arrivalDatetime DATETIME NOT NULL,
	   deliveryAddress VARCHAR(64) NOT NULL,
	   estimatedTime TIME NOT NULL,
	   clientId INT NOT NULL,
	   restaurantId INT NOT NULL,
	   deliveryManId INT NOT NULL,
	   FOREIGN KEY(clientId) REFERENCES Clients(clientId),
	   FOREIGN KEY(restaurantId) REFERENCES restaurants(restaurantId),
	   FOREIGN KEY(deliveryManId) REFERENCES DeliveryMen(deliveryManId),
	   CONSTRAINT timePositive CHECK(estimatedTime > '00:00:00')
	   );
	    
	   	CREATE TABLE FinalPrices(
	   finalPriceId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   finalPrice DOUBLE NOT NULL,
	   discountId INT NOT NULL,
	   deliverId INT NOT NULL,
	   FOREIGN KEY(discountId) REFERENCES Discounts(discountId),
	   FOREIGN KEY(deliverId) REFERENCES Delivers(deliverId)
	   );
	    
	   	CREATE TABLE ProductLines(
	   productLineId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	   productQuantity INT NOT NULL,
	   productType ENUM('Tapa','Media Racion', 'Plato') NOT NULL, 
	   productId INT NOT NULL,
	   deliverId INT NOT NULL,
	   FOREIGN KEY(productId) REFERENCES Products(productId),
	   FOREIGN KEY(deliverId) REFERENCES Delivers(deliverId)
	   );
   END //
DELIMITER ;
-- Llamamos al procemiento para crear las tablas de la base de datos
CALL createTables();

-- Este procedimiento borra todos los datos de un usuario de la base de datos aportandole su nombre de usuario
DELIMITER //
CREATE OR REPLACE PROCEDURE procDeleteuser(usernameN CHAR(32))
	BEGIN
		DECLARE user_ID INT;
		DECLARE client_ID INT;
		DECLARE delivery_ManID INT;
		SET user_ID =(SELECT userId FROM users WHERE username=usernameN);
		SET client_ID =(SELECT clientId FROM clients WHERE userId=user_ID);
		SET delivery_ManID=(SELECT deliveryManId FROM deliveryMen WHERE userId=user_ID);
		IF(client_ID IS NULL)THEN
		DELETE FROM finalprices WHERE deliverId IN (SELECT deliverId FROM delivers WHERE deliveryManId=delivery_ManID);
		DELETE FROM productlines WHERE deliverId IN (SELECT deliverId FROM delivers WHERE deliveryManId=delivery_ManID);
		DELETE FROM delivers WHERE deliveryManId=delivery_ManID;
		DELETE FROM deliverymen WHERE userId=user_ID;
		DELETE FROM users WHERE userId=user_ID;
		DELETE FROM users WHERE userId=user_ID;
		ELSE
		DELETE FROM addresses WHERE clientId=client_ID;
		DELETE FROM finalprices WHERE deliverId IN (SELECT deliverId FROM delivers WHERE clientId=client_ID) ;
		DELETE FROM productlines WHERE deliverId IN (SELECT deliverId FROM delivers WHERE clientId=client_ID);
		DELETE FROM delivers WHERE clientId=client_ID;
		DELETE FROM clients WHERE userId=user_ID;
		DELETE FROM users WHERE userId=user_ID;
		END IF;	
	END //
DELIMITER ;

-- Este procedimiento muestra una vista con el nombre, precio y restaurantId del producto mas caro por restaurante
DELIMITER //
CREATE OR REPLACE PROCEDURE proc_loop()
BEGIN
  DECLARE counter BIGINT DEFAULT 0;
  DECLARE n_restaurantes INT ;
  SET n_restaurantes = (SELECT max(restaurantid) FROM products) ;
  my_loop: LOOP
		SET counter=counter+1;
		SELECT `name`, price, restaurantId FROM products WHERE price=(SELECT max(price) FROM products WHERE restaurantid=counter);
		IF counter=n_restaurantes THEN
      	LEAVE my_loop;
    	END IF;
  END LOOP my_loop;
END //
DELIMITER ;

-- TRIGGERS

-- Este trigger comprueba que el numero de telefono de un usuario este formado por digitos numericos
DELIMITER //
CREATE OR REPLACE TRIGGER validPhoneUsersNumber
   BEFORE INSERT ON Users
   FOR EACH ROW
   BEGIN
      IF(NEW.phone NOT REGEXP'[0-9]{9}')THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='El usuario no ha usado el formato correcto.';
      END IF;
   END //
DELIMITER ;

-- Este trigger comprueba que el numero de telefono de un restaurante este formado por digitos numericos
DELIMITER //
CREATE OR REPLACE TRIGGER validPhoneRestaurantNumber
   BEFORE INSERT ON Restaurants
   FOR EACH ROW
   BEGIN
      IF(NEW.phone NOT REGEXP'[0-9]{9}')THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='El restaurante no ha usado el formato correcto.';
      END IF;
   END //
DELIMITER ;


-- Este trigger comprueba que la fecha de admision de un repartidor sea anterior a la fecha actual
DELIMITER //
CREATE OR REPLACE TRIGGER validDate
   BEFORE INSERT ON DeliveryMen
   FOR EACH ROW
   BEGIN
      IF(NEW.admissionDate>CURRENT_DATE())THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Error:La fecha debe ser anterior a la fecha actual.';
      END IF;	
   END // 
DELIMITER ;

-- Este trigger comprueba que un cliente no sea un repartidor
DELIMITER //
CREATE OR REPLACE TRIGGER clientOnDel
   BEFORE INSERT ON Clients
   FOR EACH ROW
   BEGIN
      IF(NEW.userId IN(SELECT userId FROM DeliveryMen))THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Este usuario ya es un repartidor, no puede ser cliente tambien';
      END IF;
   END // 
DELIMITER ;

-- Este trigger comprueba que un repartidor no sea un cliente
DELIMITER //
CREATE OR REPLACE TRIGGER delOnClient
   BEFORE INSERT ON DeliveryMen
   FOR EACH ROW
   BEGIN
      IF(NEW.userId IN(SELECT userId FROM Clients))THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Este usuario ya es un cliente, no puede ser repartidor tambien';
      END IF;
   END // 
DELIMITER ;

-- Este trigger comprueba que los productos de un pedido sean todos de un mismo restaurante
DELIMITER //
CREATE OR REPLACE TRIGGER sameRestaurant
    BEFORE INSERT ON productlines 
    FOR EACH ROW 
    BEGIN
        DECLARE numRes INT ;
        DECLARE counter BIGINT DEFAULT 0;
        DECLARE n_restaurantes INT ;
          SET n_restaurantes = (SELECT MAX(restaurantid) FROM products);
          my_loop: LOOP
        SET counter=counter+1;
        SET numRes = (SELECT COUNT(DISTINCT restaurantId) FROM products p WHERE p.productId IN (SELECT productId FROM productlines pl WHERE deliverId=counter));
            IF(numRes>1 ) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No puede haber productos de distintos restaurantes en un mismo pedido';
            END IF;
        IF counter=n_restaurantes THEN
          LEAVE my_loop;
        END IF;
          END LOOP my_loop;
            SET numRes = (SELECT COUNT(DISTINCT restaurantId) FROM products p WHERE p.productId IN (SELECT productId FROM productlines pl WHERE NEW.deliverId=deliverId));
    END//
DELIMITER ;
-- Este trigger comprueba que un los productos del pedido estan disponibles
DELIMITER //
CREATE OR REPLACE TRIGGER Disponibility
   BEFORE INSERT ON productlines
   FOR EACH ROW
   BEGIN
      IF( (SELECT disponibility FROM products WHERE productId=NEW.productId ) = False)THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Los productos del pedido no estan disponibles';
      END IF;
   END // 
DELIMITER ;

-- FUNCIONES

-- Esta funcion calcula el numero de pedidos que se han hecho en un restaurante
DELIMITER //
CREATE OR REPLACE FUNCTION deliversFromRestaurants(resId INT) RETURNS INT
	BEGIN
		DECLARE numDelivers INT;
		SET numDelivers = (SELECT COUNT(*) FROM delivers WHERE restaurantId=resId && arrivalDateTime<CURRENT_DATE());
		IF(numDelivers IS NULL)THEN 
		SET numDelivers=0;
		END IF;
		RETURN numDelivers;
	END//
DELIMITER ;

-- Esta funcion devuelve los datos del usuario y la ultima fecha de pedido de un cliente
DELIMITER //
CREATE OR REPLACE FUNCTION lastDeliverForEachClient(clId INT ) RETURNS VARCHAR(256) 
	BEGIN
		DECLARE datee VARCHAR(128);
		DECLARE namee VARCHAR(128);
		DECLARE returnn VARCHAR(256);
		SET datee = (SELECT MAX(arrivalDateTime) FROM delivers WHERE delivers.clientId = clId);
		SET namee = CAST((SELECT CONCAT(`name`, ' ', surname1, ' ', surname2, ' con nombre de usuario ', username) FROM clients NATURAL JOIN 
		users WHERE users.userId=clients.userId AND clients.clientId = clId) AS CHAR);
		SET returnn = CONCAT(namee,' hizo su ultimo pedido el  ',datee);
		RETURN returnn;
	END//
DELIMITER ;

-- Esta funcion devuelve el precio total de una productLine
DELIMITER //
CREATE OR REPLACE FUNCTION priceProductLine(plId INT) RETURNS DOUBLE
	BEGIN
		DECLARE pricee DOUBLE ;
		DECLARE productQ INT ;
		SET pricee=(SELECT price FROM products WHERE productId IN(SELECT productId FROM productlines WHERE productLineId=plId));
		SET productQ=(SELECT productQuantity FROM productlines WHERE productlines.productLineId=plId);
		RETURN pricee*productQ;
	END//
DELIMITER ;


-- CURSORES

-- Este cursor realiza la media de los precios de todos los productos de la base de datos
DELIMITER //
CREATE OR REPLACE FUNCTION avgPrices()
RETURNS DOUBLE  
BEGIN 
	DECLARE suma DOUBLE;
	DECLARE numProducts INT;
	DECLARE product ROW TYPE of products;
	DECLARE done BOOLEAN DEFAULT FALSE ;
	DECLARE curProducts CURSOR FOR SELECT * FROM products;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done := TRUE;
	SET numProducts = (SELECT COUNT(*) FROM products);
	SET suma = 0;
	OPEN curProducts ;
	readLoop: LOOP
		FETCH curProducts INTO product;
		IF done THEN
			LEAVE readLoop;
		END IF;
		SET suma = suma + product.price;
	END LOOP;
	SET suma = suma/ numProducts;
	CLOSE curProducts;
	RETURN suma;
	END//
DELIMITER ;

-- Este cursor calcula la media de los precios de los productos de un restaurante
DELIMITER //
CREATE OR REPLACE FUNCTION avgPriceFromRestaurant(restaurant INT )
RETURNS DOUBLE  
BEGIN 
	DECLARE suma DOUBLE;
	DECLARE numProducts INT;
	DECLARE product ROW TYPE of products;
	DECLARE done BOOLEAN DEFAULT FALSE ;
	DECLARE curProducts CURSOR FOR SELECT * FROM products WHERE restaurantId=restaurant;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done := TRUE ;
	SET numProducts = (SELECT COUNT(*) FROM products WHERE restaurantId=restaurant);
	SET suma = 0;
	OPEN curProducts ;
	readLoop: LOOP
		FETCH curProducts INTO product;
		IF done THEN
			LEAVE readLoop;
		END IF;
		SET suma = suma + product.price;
	END LOOP;
	SET suma = suma/ numProducts;
	CLOSE curProducts;
	RETURN suma;
	END//
DELIMITER ;

-- Este cursor devuelve el precio total de un pedido
DELIMITER //
CREATE OR REPLACE FUNCTION TotalPrice(dId INT) RETURNS DOUBLE
BEGIN 
	DECLARE res DOUBLE;
	DECLARE shippingPricee DOUBLE;
	DECLARE finalpriceID INT DEFAULT(1);
	DECLARE discount DOUBLE DEFAULT(1.0);
	DECLARE numDel INT;
	DECLARE productLine ROW TYPE of productlines;
	DECLARE done BOOLEAN DEFAULT FALSE ;
	DECLARE curProductLines CURSOR FOR SELECT * FROM productlines WHERE dId=deliverId;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done := TRUE;
	SET res = 0;
	OPEN curProductLines ;
	readLoop: LOOP
		FETCH curProductLines INTO productLine;
		IF done THEN
			LEAVE readLoop;
		END IF;
		SET res = res + priceProductLine(productLine.productLineId);
	END LOOP;
	CLOSE curProductLines;
	
	IF(res>10)THEN
		SET shippingPricee=0;
		ELSE
		SET shippingPricee= (SELECT shippingPrice FROM restaurants WHERE restaurantId IN(SELECT restaurantId FROM products WHERE productId IN(SELECT MIN(productId) FROM productlines where
		deliverId=dId)));
		END IF;
	SET res= res+shippingPricee;
	
	SET numDel = (SELECT COUNT(*) FROM delivers WHERE clientId IN(SELECT clientId FROM delivers WHERE deliverid=dId));
	
	   IF(numDel%5 = 0 && numDel!=0)THEN
	   	SET discount =0.7;
	   	SET finalpriceID=2;
	   END IF;
		SET res= res*discount;
		INSERT INTO finalprices VALUES(NULL, res, finalpriceID,dId);
	RETURN res;		 
	END//
DELIMITER ;

-- INSERTS

	-- INSERTS DE LA TABLA USERS
	
		-- Insert para probar el trigger validPhoneUsersNumber

-- INSERT INTO Users VALUES(NULL, 'Juan', 'Martinez', 'Perez', 'juanmrper@hotmail.com', '657A01342', 'juanmarpr', 'MartPr278', 'https://i.blogs.es/808765/dpoty-puppy-2nd--c--tracy-kirby-the-kennel-club-2/450_1000.jpg', 'Visa', '40783');

INSERT INTO Users VALUES(NULL, 'Juan', 'Martinez', 'Perez', 'juanmarper@hotmail.com', '657901342', 'juanmarper', 'MartPer278', 'https://i.blogs.es/808765/dpoty-puppy-2nd--c--tracy-kirby-the-kennel-club-2/450_1000.jpg', 'Visa', '40783');
INSERT INTO Users VALUES(NULL, 'Manuel', 'Del Moral', 'Ruidiaz', 'manudelmoral@hotmail.com', '634019872', 'manudelmoral', 'ManDelMo65', 'https://s.hs-data.com/bilder/spieler/gross/38509.jpg', 'PayPal', '41700');
INSERT INTO Users VALUES(NULL, 'Iñigo', 'Ruiz', 'Sanz', 'inigoruizsanz@hotmail.com', '678926410', 'inigoruiz', 'ruizsanz22', 'https://img.a.transfermarkt.technology/portrait/big/126751-1447152148.jpg?lm=1', 'Visa', '32895');
INSERT INTO Users VALUES(NULL, 'Carlos', 'Martinez', 'Garcia', 'carlosmartinez@hotmail.com', '689630900', 'carlosmartgarcia', 'martinez090', 'https://static.elcorreo.com/www/multimedia/202206/10/media/cortadas/carlos-martinez-kNLB-U17038338505530H-624x385@El%20Correo.jpg', 'PayPal', '56109');
INSERT INTO Users VALUES(NULL, 'Adam', 'García ', 'Rodríguez ', 'adangarrod@hotmail.com', '657441342', 'adangarrod', 'megustaelqueso', 'https://www.mundodeportivo.com/files/og_thumbnail/uploads/2012/11/20/60e5df5e68332.jpeg', 'Visa', '50483');
INSERT INTO Users VALUES(NULL, 'Andrea', 'González ', 'Garcia', 'andregonza@hotmail.com', '657891388', 'andregonza', 'odiolosperros', 'https://img.a.transfermarkt.technology/portrait/big/126751-1447152148.jpg?lm=1', 'Visa', '45423');
INSERT INTO Users VALUES(NULL, 'Julio', 'Maldonado', 'Hernández ', 'juliomald@hotmail.com', '677881342', 'juliomald', 'Juice, gotas', 'https://i.blogs.es/808765/dpoty-puppy-2nd--c--tracy-kirby-the-kennel-club-2/450_1000.jpg', 'Visa', '20423');
INSERT INTO Users VALUES(NULL, 'Bran', 'Fernández', 'López ', 'brandonsandd@hotmail.com', '657891333', 'brandonsandd', 'Una fórmula', 'https://www.mundodeportivo.com/files/og_thumbnail/uploads/2012/11/20/60e5df5e68332.jpeg', 'PayPal', '48764');
INSERT INTO Users VALUES(NULL, 'Dante', 'Martínez ', 'Pérez ', 'dantmartpz@hotmail.com', '657111341', 'dantmartpz', 'Valtteri Bottas', 'https://img.a.transfermarkt.technology/portrait/big/126751-1447152148.jpg?lm=1', 'Visa', '41701');
INSERT INTO Users VALUES(NULL, 'Erik', 'Sánchez ', 'Berlanga', 'berlangaeriks@hotmail.com', '611891342', 'berlangaeriks', 'Botegga Veneta', 'https://www.mundodeportivo.com/files/og_thumbnail/uploads/2012/11/20/60e5df5e68332.jpeg', 'Visa', '54424');
INSERT INTO Users VALUES(NULL, 'Laura', 'Martín ', 'Jiménez ', 'lauramartin98@hotmail.com', '644491342', 'lauramartin98', 'las botas', 'https://www.mundodeportivo.com/files/og_thumbnail/uploads/2012/11/20/60e5df5e68332.jpeg', 'PayPal', '50489');
INSERT INTO Users VALUES(NULL, 'Izan', 'Hernández ', 'Gómez ', 'izaaaan@hotmail.com', '657891349', 'izaaaan', 'Y otros pare', 'https://www.manejandodatos.es/2014/04/vincular-mysql-mariadb-msaccess/', 'PayPal', '50423');
INSERT INTO Users VALUES(NULL, 'Hugo', 'Díaz ', 'Garcia', 'jhugodiazg@hotmail.com', '657895642', 'jhugodiazg', 'para mi garo—', 'https://www.mundodeportivo.com/files/og_thumbnail/uploads/2012/11/20/60e5df5e68332.jpeg', 'Visa', '56623');
INSERT INTO Users VALUES(NULL, 'Marco', 'Moreno ', 'Jiménez ', 'mmjiiminez@hotmail.com', '688891342', 'mmjiiminez78', 'comarmoreno12', 'https://i.blogs.es/808765/dpoty-puppy-2nd--c--tracy-kirby-the-kennel-club-2/450_1000.jpg', 'PayPal', '47484');
INSERT INTO Users VALUES(NULL, 'Jose', 'Fernánde ', 'Costa ', 'jfcost4@hotmail.com', '678333342', 'jfcost4', 'j0s3fc0sta', 'https://s.hs-data.com/bilder/spieler/gross/38509.jpg', 'Visa', '50001');


	-- INSERTS DE LA TABLA CLIENTS

INSERT INTO Clients VALUES(NULL, 1);
INSERT INTO Clients VALUES(NULL, 2);
INSERT INTO Clients VALUES(NULL, 3);
INSERT INTO Clients VALUES(NULL, 4);
INSERT INTO Clients VALUES(NULL, 6);
INSERT INTO Clients VALUES(NULL, 7);
INSERT INTO Clients VALUES(NULL, 10);
INSERT INTO Clients VALUES(NULL, 11);
INSERT INTO Clients VALUES(NULL, 13);


	-- INSERTS DE LA TABLA DISCOUNTS

INSERT INTO Discounts VALUES(1, 1.0);
INSERT INTO Discounts VALUES(2, 0.7);


	-- INSERTS DE LA TABLA ADDRESSES

INSERT INTO Addresses VALUES(NULL, 'Paseo Independencia 129', 1);
INSERT INTO Addresses VALUES(NULL, 'Paseo Independencia 130', 2);
INSERT INTO Addresses VALUES(NULL, 'Paseo Independencia 131', 1);
INSERT INTO Addresses VALUES(NULL, 'Calle Marie Curie 42', 1);
INSERT INTO Addresses VALUES(NULL, 'Avda de la Paz 89', 3);
INSERT INTO Addresses VALUES(NULL, 'Plaza del Carmen 2', 4);
INSERT INTO Addresses VALUES(NULL, 'Avda de España 19', 5);
INSERT INTO Addresses VALUES(NULL, 'Plaza del Carmen 6', 6);
INSERT INTO Addresses VALUES(NULL, 'Calle Canónigo 12', 7);
INSERT INTO Addresses VALUES(NULL, 'Avda de la Constitución 3', 8);
INSERT INTO Addresses VALUES(NULL, 'Calle Adolfo Suarez', 8);
INSERT INTO Addresses VALUES(NULL, 'Plaza de Santa Ana 2', 8);
INSERT INTO Addresses VALUES(NULL, ' Avda de las delicias 2', 9);


	-- INSERTS DE LA TABLA DELIVERYMEN
	
		-- Insert para probar el trigger validDate

-- INSERT INTO DeliveryMen VALUES(NULL, '2023-01-10', 'Coche', 5);

		-- Insert para probar el trigger delOnClient

-- INSERT INTO DeliveryMen VALUES(NULL, '2020-10-08','Bicicleta', 1);

INSERT INTO DeliveryMen VALUES(NULL, '2022-01-10', 'Coche', 5);
INSERT INTO DeliveryMen VALUES(NULL, '2021-01-01', 'Coche', 8);
INSERT INTO DeliveryMen VALUES(NULL, '2022-01-08', 'Moto', 9);
INSERT INTO DeliveryMen VALUES(NULL, '2022-04-10', 'Bicicleta', 14);
INSERT INTO DeliveryMen VALUES(NULL, '2021-06-10', 'Coche', 15);

-- Insert para probar el trigger clientOnDel

-- INSERT INTO Clients VALUES(NULL, 5);

	-- INSERTS DE LA TABLA RESTAURANTS
	
INSERT INTO Restaurants VALUES(NULL, 'La Gran Familia Mediterranea', 'Comida especializada en productos obtenidos de la zona del mediterráneo español', 'Avda Gran Vía 19', '42378', '981601927', 'https://lagranfamiliamediterranea.com/assets/logo_header.png', 'Open', 'Mediterranean', 2);
INSERT INTO Restaurants VALUES(NULL, 'Sushi Panda', 'Comida de origen japones importada', 'Calle Ramón Gutierrez 9', '12076', '932606411', 'https://sushipanda.es/wp-content/uploads/2020/10/LOGO-SUSHIPANDA-scaled.jpg', 'Temporarily Closed', 'Japanese', 3);
INSERT INTO Restaurants VALUES(NULL, 'Doner Kebap', 'Kebabs y Dürums con carne importada de Turquía', 'Avda Reina Mercedes 75','12076', '955783210', 'https://media-cdn.tripadvisor.com/media/photo-s/06/07/d2/ae/king-doner-kebab.jpg', 'Permanently Closed', 'Turkey', 1);


	-- INSERTS DE LA TABLA PRODUCTS

INSERT INTO Products VALUES(NULL, 'Hamburguesa de buey ibérico', 'Hamburguesa en pan de mantequilla con carne de buey 100% ibérico', 13.1, 'https://imag.bonviveur.com/hamburguesas-listas-para-degustar.jpg', TRUE, 1);
INSERT INTO Products VALUES(NULL, 'Papas Bravas', 'Patatas cocidas acompañadas de salsa brava extra picante', 7.7, 'https://www.goya.com/media/7699/spicy-potatoes.jpg?quality=80', FALSE, 1);
INSERT INTO Products VALUES(NULL, 'Carrillada Ibérica en salsa', 'Carrillada de ternera iberica española en su salsa', 8.5, 'https://img-global.cpcdn.com/recipes/f9c79d9a83272c3a/1200x630cq70/photo.jpg', TRUE, 1);
INSERT INTO Products VALUES(NULL, 'Ensalada de pescado', 'Ensalada con peces recien pescados del mar mediterraneo', 6.5, 'https://www.hogarmania.com/archivos/201105/ensalada-templada-de-pescado-668x400x80xX.jpg ', TRUE, 1);
INSERT INTO Products VALUES(NULL, 'Makis de pepino', 'Arroz y pepino envuelto en arroz y alga', 5.6, 'https://www.sushitake.eu/wp-content/uploads/2019/06/053-Maki-Pepino-878.jpg', TRUE, 2);
INSERT INTO Products VALUES(NULL, 'Poke de salmon', 'Bowl de salmón con aguacate y arroz', 9.0, 'https://www.pequerecetas.com/wp-content/uploads/2019/05/poke-bowl-hawaiano-receta.jpg', TRUE, 2);
INSERT INTO Products VALUES(NULL, 'Bolas de arroz', 'Clasicas bolas de arroz rellenas de carne o pescado(a elegir)', 4.6, 'https://www.hazteveg.com/img/recipes/full/201302/R07-45221.jpg', FALSE, 2);
INSERT INTO Products VALUES(NULL, 'Sashimi de atún', 'Atún japonés crudo', 6.6, 'https://okdiario.com/img/2018/12/26/receta-de-sashimi-de-atun-1.jpg', TRUE, 2);
INSERT INTO Products VALUES(NULL, 'Dürum mixto', 'Rollo de carne de ternera y pollo con verduras y salsa', 4.1, 'https://kebabsevillaeste.com/wp-content/uploads/2020/06/DURUN-KEBAP-1.jpg', TRUE, 3);
INSERT INTO Products VALUES(NULL, 'Kebab de ternera', 'Pan pita relleno con ternera, verduras y salsa', 5.9, 'https://media.istockphoto.com/id/851493796/es/foto/primer-plano-de-s%C3%A1ndwich-de-kebab.jpg?s=612x612&w=0&k=20&c=wj2BpKqk8IReC78RIDEG6cUCN7WDAtqXdwrFbUUZHaQ=', FALSE, 3);
INSERT INTO Products VALUES(NULL, 'Falafel de pollo', ' plato muy popular hecho a base de pollo y sazonado con especias', 4.2, 'https://thumbs.dreamstime.com/b/falafel-de-pollo-aislado-en-un-bol-arcilla-decorado-con-perejil-comida-vegana-173599101.jpg ', TRUE, 3);
INSERT INTO Products VALUES(NULL, 'Papas gratinadas con bacon', 'Patatas gratinadas con bacon y 4 quesos', 3.7, 'https://www.divinacocina.es/wp-content/uploads/patatas-con-queso-y-bacon1.jpg', TRUE, 3);

	-- INSERTS DE LA TABLA DELIVERS
		-- Insert para probar el trigger sameRestaurant

-- INSERT INTO Delivers VALUES(NULL, '2022-01-10 21:15:00', '2022-01-10 21:45:00','Calle Marie Curie 40', '00:35:00',1,1,1);

INSERT INTO Delivers VALUES(NULL, '2022-01-13 21:15:00', '2022-01-10 21:30:00','Calle Marie Curie 40', '00:15:00',1,1,1);
INSERT INTO Delivers VALUES(NULL, '2022-01-13 21:15:00', '2022-01-10 21:30:00','Calle Marie Curie 40', '00:15:00',1,1,1);
INSERT INTO Delivers VALUES(NULL, '2022-01-13 21:15:00', '2022-01-10 21:30:00','Calle Marie Curie 40', '00:15:00',1,1,1);
INSERT INTO Delivers VALUES(NULL, '2022-01-13 21:15:00', '2022-01-10 21:30:00','Calle Marie Curie 40', '00:15:00',1,1,1);
-- INSERT INTO Delivers VALUES(NULL, '2022-01-13 21:15:00', '2022-01-10 21:30:00','Calle Marie Curie 40', '00:15:00',1,1,1);
INSERT INTO Delivers VALUES(NULL, '2022-01-10 14:15:00', '2022-01-10 14:30:00','Plaza del Carmen 2', '00:15:00',4,1,2);
INSERT INTO Delivers VALUES(NULL, '2022-01-10 14:30:00', '2022-01-10 14:45:00','Calle Marie Curie 40', '00:15:00',2,2,3);
INSERT INTO Delivers VALUES(NULL, '2022-01-10 14:45:00', '2022-01-10 15:00:00','Paseo Independencia 129', '00:15:00',7,3,1);
INSERT INTO Delivers VALUES(NULL, '2022-01-10 15:00:00', '2022-01-10 15:15:00','Paseo Independencia 129', '00:15:00',2,1,1);



	-- INSERTS DE LA TABLA PRODUCTLINES
	
		-- Insert para probar el trigger Disponibility
		
-- INSERT INTO ProductLines VALUES(NULL, 2, 'Tapa', 3,2);
-- INSERT INTO ProductLines VALUES(NULL, 1, 'Tapa', 5,3);	
-- INSERT INTO ProductLines VALUES(NULL, 1, 'Tapa', 6,3);
-- INSERT INTO ProductLines VALUES(NULL, 1, 'Tapa', 1,3);
-- INSERT INTO ProductLines VALUES(NULL, 1, 'Tapa', 6,3);
	
	
INSERT INTO ProductLines VALUES(NULL, 1, 'Media Racion', 3,1);
INSERT INTO ProductLines VALUES(NULL, 3, 'Plato', 3,1);
INSERT INTO ProductLines VALUES(NULL, 2, 'Tapa', 1,1);
INSERT INTO ProductLines VALUES(NULL, 2, 'Tapa', 1,2);
INSERT INTO ProductLines VALUES(NULL, 2, 'Tapa', 1,2);
INSERT INTO ProductLines VALUES(NULL, 2, 'Tapa', 3,2);
INSERT INTO ProductLines VALUES(NULL, 2, 'Tapa', 5,4);
INSERT INTO ProductLines VALUES(NULL, 2, 'Tapa', 4,5);



-- LLAMADAS A LAS FUNCIONES Y CURSORES
SELECT avgPrices();
SELECT deliversFromRestaurants(1);
SELECT avgPriceFromRestaurant(1);
SELECT lastDeliverForEachClient(1);
SELECT priceProductLine(1);
SELECT totalPrice(1);

-- Vistas 

CREATE OR REPLACE VIEW viewClientsWithDelivers AS
	SELECT * FROM users WHERE userId IN(SELECT userId FROM clients WHERE clientId IN(SELECT clientId FROM delivers));

CREATE OR REPLACE VIEW viewDisponibleFood AS
	SELECT `name`,description,price,image,restaurantId FROM products p WHERE p.disponibility=TRUE;
	
-- Algunos select con las vistas para comprobar que funcionan
SELECT * FROM viewClientsWithDelivers;
SELECT * FROM viewDisponibleFood;
SELECT `name`,MAX(price) FROM viewDisponibleFood;

-- LLAMADAS A PROCEDIMIENTOS
CALL proc_loop();
-- CALL procDeleteuser('manudelmoral');